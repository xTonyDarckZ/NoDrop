<h2>NoDrops</h2>

![My image](https://github.com/Yupai/NoDrops/blob/master/NoDrops.png)

<h4>Version: 1.0</h4>

<h4>Type</h4>
PocketMine-MP Plugin.

<h4>Description</h4>
The players can't drop items.

<h4>Installation Instructions</h4>
Download *NoDrops_v1.0.phar*, put it in your puglins and restart your server.

<h4>Config</h4>
For the moment *NoDrops* doesn't have config.

<h4>Permissions</h4>
For the moment *NoDrops* doesn't have permissions.

<h4>Tested</h4>
*NoDrops* was tested in:

* **Genisys 1.1**

<h4>Notes</h4>
Try it on other software and let me know please.

<h4>Info</h4>

* Twitter: **@Yupai90**
